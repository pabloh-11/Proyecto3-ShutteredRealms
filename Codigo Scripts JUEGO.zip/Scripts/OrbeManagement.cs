// Importa las bibliotecas necesarias para trabajar con colecciones, Unity y escenas
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; // Para cargar escenas
using UnityEngine.UI; // Para manejar UI, como Text e Image

// Clase para gestionar la recolección de orbes y transición de niveles
public class OrbeManagement : MonoBehaviour
{
    // Referencias a los componentes UI, como la imagen de nivel completado y los textos de orbes
    public Image levelCleared;
    //public GameObject transition; // (Desactivado) Para una transición visual, por ejemplo, antes de cambiar de escena
    public Text totalOrbes; // Muestra el número total de orbes en el nivel
    public Text orbeCollected; // Muestra el número de orbes recolectados por el jugador

    // Contador de los orbes en el nivel
    private int totalOrbesInLevel;

    // Método que se llama al inicio del juego
    private void Start()
    {
        // Inicializa el contador de orbes en el nivel, basándose en la cantidad de hijos del objeto
        totalOrbesInLevel = transform.childCount;
    }

    // Método que se llama cada frame para actualizar la información
    private void Update()
    {
        // Llama a la función que verifica si todos los orbes han sido recolectados
        AllOrbeCollected();

        // Actualiza los textos en la UI con los valores actuales de orbes
        totalOrbes.text = totalOrbesInLevel.ToString();
        orbeCollected.text = transform.childCount.ToString();
    }

    // Función que verifica si todos los orbes han sido recolectados
    public void AllOrbeCollected()
    {
        // Si no quedan orbes (la cantidad de hijos del objeto es 0)
        if (transform.childCount == 0)
        {
            // Muestra un mensaje en la consola de que el jugador ha conseguido todos los orbes
            Debug.Log("HAS CONSEGUIDO EL ORBE!!");

            // Activa la imagen de "nivel completado" en la UI
            levelCleared.gameObject.SetActive(true);

            // Activa una transición (comentado por ahora)
            // Para transicion transition.SetActive(true);

            // Llama a la función que cambia de escena después de un retraso de 2 segundos
            Invoke("ChangeScene", 2);
        }
    }

    // Función que cambia a la siguiente escena
    void ChangeScene()
    {
        // Carga la siguiente escena en el índice (la siguiente en la lista de build de Unity)
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
}
