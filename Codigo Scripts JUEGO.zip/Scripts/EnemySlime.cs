// Importa las bibliotecas necesarias para trabajar con colecciones y Unity
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Clase que maneja el comportamiento del enemigo Slime (o cualquier otro enemigo similar)
public class EnemySlime : MonoBehaviour
{
    // Método que se llama cuando el objeto colisiona con otro objeto
    private void OnCollisionEnter2D(Collision2D collision)
    {
        // 1. Verifica si el objeto que colisiona tiene la etiqueta "Player"
        if(collision.transform.CompareTag("Player"))
        {
            // 2. Muestra un mensaje en la consola indicando que el jugador ha recibido daño
            Debug.Log("Player Damage");

            // 3. Llama al método PlayerDamage del componente PlayerRespawn del jugador
            // Esto es donde se maneja la lógica del daño al jugador (como perder vida o cambiar su estado)
            collision.transform.GetComponent<PlayerRespawn>().PlayerDamage();
        }
    }
}
