// Importación de bibliotecas necesarias para el uso de colecciones y Unity
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Clase que gestiona el movimiento del jugador utilizando un joystick
public class PlayerMoveJoystick : MonoBehaviour
{
    // Variables para almacenar el movimiento horizontal y vertical
    private float horizontalMove = 0f;
    private float verticalMove = 0f;

    // Referencia al joystick y las velocidades de movimiento
    public Joystick joystick;
    public float runSpeedHorizontal = 2;
    public float runSpeed = 1.25f;
    public float jumpSpeed = 5;
    public float doubleJumpSpeed = 2.5f;
    private bool canDoubleJump;

    // Referencias a componentes de Rigidbody2D, SpriteRenderer y Animator
    Rigidbody2D rb2D;
    public SpriteRenderer spriteRenderer;
    public Animator animator;

    // Método de inicio que inicializa el Rigidbody2D del jugador
    void Start()
    {
        rb2D = GetComponent<Rigidbody2D>();
    }

    // Método que se llama cada frame para actualizar las animaciones y controlar la orientación del jugador
    private void Update()
    {
        // Control de la animación de correr y la dirección del personaje
        if (horizontalMove > 0)
        {
            spriteRenderer.flipX = false;  // Orienta el sprite mirando hacia la derecha
            animator.SetBool("run", true);  // Activa la animación de correr
        }
        else if (horizontalMove < 0)
        {
            spriteRenderer.flipX = true;  // Orienta el sprite mirando hacia la izquierda
            animator.SetBool("run", true);  // Activa la animación de correr
        }
        else
        {
            animator.SetBool("run", false);  // Desactiva la animación de correr si no se mueve
        }

        // Control de las animaciones de salto y caída
        if (CheckGround.isGrounded == false)
        {
            animator.SetBool("Jump", true);  // Activa la animación de salto si no está en el suelo
            animator.SetBool("run", false);  // Desactiva la animación de correr si está en el aire
        }
        if (CheckGround.isGrounded == true)
        {
            animator.SetBool("Jump", false);  // Desactiva la animación de salto si está en el suelo
            animator.SetBool("Falling", false);  // Desactiva la animación de caída si está en el suelo
        }
        
        // Control de la animación de caída según la velocidad vertical
        if (rb2D.velocity.y < 0)
        {
            animator.SetBool("Falling", true);  // Activa la animación de caída si está descendiendo
        }
        else if (rb2D.velocity.y > 0)
        {
            animator.SetBool("Falling", false);  // Desactiva la animación de caída si está subiendo
        }
    }

    // Método que se llama en intervalos fijos para gestionar el movimiento horizontal basado en el joystick
    void FixedUpdate()
    {
        horizontalMove = joystick.Horizontal * runSpeedHorizontal;  // Calcula el movimiento horizontal basado en la entrada del joystick
        transform.position += new Vector3(horizontalMove, 0, 0) * Time.deltaTime * runSpeed;  // Mueve al jugador horizontalmente
    }

    // Método para gestionar los saltos, incluyendo el doble salto
    public void Jump()
    {
        // Si el jugador está en el suelo, realiza un salto normal
        if (CheckGround.isGrounded)
        {
            canDoubleJump = true;  // Permite el doble salto
            rb2D.velocity = new Vector2(rb2D.velocity.x, jumpSpeed);  // Aplica la velocidad de salto
        }
        else
        {
            // Si el jugador no está en el suelo, permite el doble salto si es posible
            if (canDoubleJump)
            {
                rb2D.velocity = new Vector2(rb2D.velocity.x, doubleJumpSpeed);  // Aplica la velocidad del doble salto
                canDoubleJump = false;  // Desactiva el doble salto
            }
        }
    }
}
