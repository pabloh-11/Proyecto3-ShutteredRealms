// Importa las bibliotecas necesarias para trabajar con colecciones y Unity
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Clase que maneja los puntos de control
public class CheckPoint : MonoBehaviour
{
    // Método que se llama cuando el objeto entra en contacto con otro objeto (en este caso, el jugador)
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // 1. Verifica si el objeto que colisiona tiene la etiqueta "Player"
        if (collision.CompareTag("Player"))
        {
            // 2. Llama al método ReachedCheckPoint del componente PlayerRespawn, pasando la posición del checkpoint como parámetros
            collision.GetComponent<PlayerRespawn>().ReachedCheckPoint(transform.position.x, transform.position.y);

            // 3. Activa el Animator del checkpoint para animar el objeto (por ejemplo, cambiar su estado visual)
            GetComponent<Animator>().enabled = true;
        }
    }
}
