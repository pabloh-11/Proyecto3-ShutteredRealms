// Importación de bibliotecas necesarias
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// Clase que gestiona la vida del jugador y su reseteo al morir
public class PlayerRespawn : MonoBehaviour
{
    // Referencia a los objetos de corazón para mostrar la vida del jugador
    public GameObject[] hearts;
    private int life;  // Contador de vidas del jugador
    private float CheckPointPositionX, CheckPointPositionY;  // Posición del último checkpoint

    // Referencia al Animator para reproducir animaciones
    public Animator animator;

    // Método de inicio
    void Start()
    {
        life = hearts.Length;  // Inicializa la vida con el número de corazones

        // Si existe una posición de checkpoint guardada, coloca al jugador en ella
        if (PlayerPrefs.GetFloat("CheckPointPositionX") != 0)
        {
            transform.position = new Vector2(PlayerPrefs.GetFloat("CheckPointPositionX"), PlayerPrefs.GetFloat("CheckPointPositionY"));
        }
    }

    // Método que guarda la posición del checkpoint cuando el jugador lo alcanza
    public void ReachedCheckPoint(float x, float y)
    {
        PlayerPrefs.SetFloat("CheckPointPositionX", x);
        PlayerPrefs.SetFloat("CheckPointPositionY", y);
    }

    // Método para comprobar la vida del jugador y gestionar las animaciones o reseteo
    private void CheckLife()
    {
        // Si no tiene vida, destruye el primer corazón y reinicia la escena
        if (life < 1)
        {
            Destroy(hearts[0].gameObject);
            animator.Play("hit");  // Reproduce la animación de daño
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);  // Reinicia la escena
        }
        // Si le queda una vida, destruye el segundo corazón
        else if (life < 2)
        {
            Destroy(hearts[1].gameObject);
            animator.Play("hit");
        }
        // Si le queda dos vidas, destruye el tercer corazón
        else if (life < 3)
        {
            Destroy(hearts[2].gameObject);
            animator.Play("hit");
        }
    }

    // Método para gestionar el daño al jugador
    public void PlayerDamage()
    {
        life--;  // Resta una vida al jugador
        CheckLife();  // Revisa si el jugador se queda sin vida
    }
}
