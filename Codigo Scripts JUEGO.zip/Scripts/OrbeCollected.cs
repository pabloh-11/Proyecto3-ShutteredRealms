// Importa las bibliotecas necesarias para trabajar con colecciones, Unity y el audio
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;  // Para trabajar con audio en Unity

// Clase para manejar el comportamiento de un objeto Orbe que el jugador puede recoger
public class OrbeCollected : MonoBehaviour
{
    // Referencia al componente AudioSource para reproducir un sonido al recoger el Orbe
    public AudioSource clip;

    // Método que se llama cuando otro objeto entra en el área de colisión con el orbe
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // 1. Verifica si el objeto que colisiona tiene la etiqueta "Player"
        if (collision.CompareTag("Player"))
        {
            // 2. Desactiva el sprite del orbe (lo hace invisible)
            GetComponent<SpriteRenderer>().enabled = false;

            // 3. Activa un hijo del objeto (probablemente una animación o efecto visual) para mostrar algo al recoger el orbe
            gameObject.transform.GetChild(0).gameObject.SetActive(true);

            // 4. Destruye el objeto Orbe después de 0.5 segundos para dar tiempo a la animación o efecto
            Destroy(gameObject, 0.5f);

            // 5. Reproduce el sonido asociado al Orbe al ser recogido
            clip.Play();
        }
    }
}
