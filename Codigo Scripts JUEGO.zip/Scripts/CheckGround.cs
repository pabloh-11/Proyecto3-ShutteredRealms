// Importa las bibliotecas necesarias para trabajar con colecciones y Unity
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Clase que verifica si el personaje está tocando el suelo
public class CheckGround : MonoBehaviour
{
    // Variable estática que indica si el objeto está tocando el suelo (acceso global)
    public static bool isGrounded;

    // Método que se llama cuando el objeto entra en contacto con otro objeto (detecta el suelo)
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Establece que el objeto está en el suelo
        isGrounded = true;
    }

    // Método que se llama cuando el objeto deja de estar en contacto con otro objeto (sale del suelo)
    private void OnTriggerExit2D(Collider2D collision)
    {
        // Establece que el objeto ya no está en el suelo
        isGrounded = false;
    }
}

