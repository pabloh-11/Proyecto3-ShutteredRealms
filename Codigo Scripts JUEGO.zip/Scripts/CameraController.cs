// Importa las bibliotecas necesarias de Unity
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Controlador de la cámara (se asigna a un GameObject en Unity)
public class CameraController : MonoBehaviour
{
    // Referencia al objetivo que va a seguir la cámara (puede ser el jugador u otro objeto)
    public Transform target;

    // Velocidad de seguimiento de la cámara (cuán rápido se mueve hacia la posición deseada)
    public float speed = 0.5f;

    // Desplazamiento entre la cámara y el objetivo (para que no esté pegada al objetivo)
    public Vector3 offset;

    // Este método se ejecuta después de que todos los objetos se han actualizado (ideal para seguir al objetivo)
    private void LateUpdate()
    {
        // 1. Calcula la posición deseada para la cámara: posición del objetivo + desplazamiento (offset)
        Vector3 desiredPosition = target.position + offset;

        // 2. Mueve la cámara suavemente hacia la posición deseada
        // Utiliza Lerp para interpolar entre la posición actual de la cámara y la posición deseada
        // Lerp hace el movimiento más suave (en lugar de un cambio brusco)
        Vector3 smoothPosition = Vector3.Lerp(transform.position, desiredPosition, speed);

        // 3. Actualiza la posición de la cámara con la nueva posición suavizada
        transform.position = smoothPosition;
    }
}

