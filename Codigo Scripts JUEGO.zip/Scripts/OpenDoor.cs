using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


// Importa las bibliotecas necesarias para trabajar con colecciones y Unity
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;  // Necesario para cargar escenas

// Clase para manejar la interacción con una puerta en el juego
public class OpenDoor : MonoBehaviour
{
    // Referencia al componente Text que muestra el mensaje en la pantalla (por ejemplo, "Presiona E para entrar")
    public Text text;

    // Nombre del nivel que se cargará cuando se interactúe con la puerta
    public string levelName;

    // Estado de si el jugador está dentro del área de la puerta
    private bool inDoor = false;

    // Método que se llama cuando un objeto entra en el área del trigger (por ejemplo, el jugador entra en la zona de la puerta)
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // 1. Verifica si el objeto que colisiona tiene la etiqueta "Player"
        if(collision.gameObject.CompareTag("Player"))
        {
            // 2. Activa el mensaje que aparece en pantalla, informando al jugador que puede interactuar con la puerta
            text.gameObject.SetActive(true);
            inDoor = true;  // Marca que el jugador está dentro del área de la puerta
        }
    }

    // Método que se llama cuando un objeto sale del área del trigger (por ejemplo, el jugador se aleja de la puerta)
    private void OnTriggerExit2D(Collider2D collision)
    {
        // 3. Desactiva el mensaje de interacción con la puerta
        text.gameObject.SetActive(false);
        inDoor = false;  // Marca que el jugador ya no está en el área de la puerta
    }

    // Método que se llama cada frame para revisar las condiciones de interacción
    private void Update()
    {
        // 4. Verifica si el jugador está dentro del área de la puerta y presiona la tecla "E"
        if(inDoor && Input.GetKey("e"))
        {
            // 5. Carga la escena especificada por el nombre de la puerta (levelName)
            SceneManager.LoadScene(levelName);
        }
    }
}
