// Importación de bibliotecas necesarias
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Audio;

// Clase que gestiona la interfaz de usuario del juego (UI)
public class UIManager : MonoBehaviour
{
    // Referencia al AudioSource para reproducir efectos de sonido
    public AudioSource clip;

    // Panel de opciones que se mostrará al pausar el juego
    public GameObject optionsPanel;

    // Método que activa el panel de opciones y pausa el juego
    public void OptionsPanel()
    {
        Time.timeScale = 0;  // Pausa el tiempo en el juego (el juego se detiene)
        optionsPanel.SetActive(true);  // Muestra el panel de opciones
    }

    // Método que cierra el panel de opciones y reanuda el juego
    public void Return()
    {
        Time.timeScale = 1;  // Reanuda el tiempo en el juego
        optionsPanel.SetActive(false);  // Oculta el panel de opciones
    }

    // Método que podría gestionarse para más opciones (audio, gráficos, etc.)
    public void AnotherOptions()
    {
        // Placeholder para futuras opciones como sonido o gráficos
    }

    // Método que carga la escena del menú principal
    public void GoMainMenu()
    {
        Time.timeScale = 1;  // Asegura que el tiempo del juego se reanude al ir al menú
        SceneManager.LoadScene("MainMenu");  // Carga la escena del menú principal
    }

    // Método para salir del juego
    public void QuitGame()
    {
        Application.Quit();  // Cierra la aplicación (solo funciona en compilados, no en el editor)
    }

    // Método que reproduce un sonido cuando se hace clic en un botón
    public void PlaySoundButoon()
    {
        clip.Play();  // Reproduce el sonido asociado
    }
}
