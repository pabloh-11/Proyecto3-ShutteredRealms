// Importación de las bibliotecas necesarias para trabajar con colecciones, Unity y el movimiento físico
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Clase que gestiona el movimiento del jugador, incluyendo el salto, el doble salto, y la animación
public class PlayerMove : MonoBehaviour
{
    // Variables públicas para la velocidad de carrera, salto, doble salto, y control de caídas
    public float runSpeed = 2;
    public float jumpSpeed = 3;
    public float doubleJumpSpeed = 2.5f;
    private bool canDoubleJump;

    // Componente Rigidbody2D para manipular el movimiento físico del jugador
    Rigidbody2D rb2D;

    // Otras variables de control para mejorar el salto
    public bool betterJump = false;
    public float fallMultiplier = 0.5f;
    public float lowJumpMultiplier = 1f;

    // Componentes para manejar los sprites y las animaciones del jugador
    public SpriteRenderer spriteRenderer;
    public Animator animator;

    // Método que se llama al iniciar el juego, inicializa el componente Rigidbody2D
    void Start()
    {
        rb2D = GetComponent<Rigidbody2D>();
    }

    // Método que se llama cada frame para gestionar las entradas de usuario (movimiento y salto)
    private void Update()
    {
        // Control del salto y doble salto
        if (Input.GetKey("space"))    
        {
            if (CheckGround.isGrounded)  // Si está en el suelo, permite el salto
            {
                canDoubleJump = true;
                rb2D.velocity = new Vector2(rb2D.velocity.x, jumpSpeed);  // Aplica velocidad vertical para el salto
            }
            else
            {
                if (Input.GetKeyDown("space") && canDoubleJump)  // Si no está en el suelo, permite un doble salto
                {
                    rb2D.velocity = new Vector2(rb2D.velocity.x, doubleJumpSpeed);  // Aplica el doble salto
                    canDoubleJump = false;  // Desactiva el doble salto
                }
            }
        }

        // Actualiza el estado de las animaciones según si el jugador está en el aire o en el suelo
        if (CheckGround.isGrounded == false)
        {
            animator.SetBool("Jump", true);  // Activa la animación de salto
            animator.SetBool("run", false);  // Desactiva la animación de carrera si está en el aire
        }

        if (CheckGround.isGrounded == true)
        {
            animator.SetBool("Jump", false);  // Desactiva la animación de salto al tocar el suelo
            animator.SetBool("Falling", false);  // Desactiva la animación de caída cuando está en el suelo
        }

        // Controla la animación de caída según la velocidad vertical
        if (rb2D.velocity.y < 0)
        {
            animator.SetBool("Falling", true);  // Si está descendiendo, activa la animación de caída
        }
        else if (rb2D.velocity.y > 0)
        {
            animator.SetBool("Falling", false);  // Si está subiendo, desactiva la animación de caída
        }
    }

    // Método que se llama en intervalos fijos para gestionar el movimiento horizontal
    void FixedUpdate()
    {
        // Controla el movimiento hacia la derecha
        if (Input.GetKey("d") || Input.GetKey("right"))
        {
            rb2D.velocity = new Vector2(runSpeed, rb2D.velocity.y);  // Aplica velocidad horizontal
            spriteRenderer.flipX = false;  // Asegura que el sprite no esté volteado
            animator.SetBool("run", true);  // Activa la animación de carrera
        }
        // Controla el movimiento hacia la izquierda
        else if (Input.GetKey("a") || Input.GetKey("left"))
        {
            rb2D.velocity = new Vector2(-runSpeed, rb2D.velocity.y);  // Aplica velocidad negativa para mover hacia la izquierda
            spriteRenderer.flipX = true;  // Voltea el sprite para mirar hacia la izquierda
            animator.SetBool("run", true);  // Activa la animación de carrera
        }
        // Si no se está moviendo, detiene la animación de carrera
        else
        {
            rb2D.velocity = new Vector2(0, rb2D.velocity.y);  // Detiene el movimiento horizontal
            animator.SetBool("run", false);  // Desactiva la animación de carrera
        }

        // Si el mejor salto está activado, ajusta la velocidad de caída y salto
        if (betterJump)
        {
            if (rb2D.velocity.y < 0)
            {
                rb2D.velocity += Vector2.up * Physics2D.gravity.y * fallMultiplier * Time.deltaTime;  // Aumenta la caída
            }
            if (rb2D.velocity.y > 0 && !Input.GetKey("space"))
            {
                rb2D.velocity += Vector2.up * Physics2D.gravity.y * lowJumpMultiplier * Time.deltaTime;  // Modifica el salto para caer más rápido si se suelta el salto
            }
        }
    }
}
